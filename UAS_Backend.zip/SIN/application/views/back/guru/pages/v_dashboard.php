<!-- Content Wrapper. Contains page content -->  
<div class="content-wrapper">  
    <!-- Content Header (Page header) -->  
    <section class="content-header">  
        <h1>  
            Dashboard  
        </h1>  
        <ol class="breadcrumb">  
            <li><a href="<?= site_url('admin')?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>  
        </ol>  
    </section>  
    <section class="content">  
        <div class="box box-info">  
            <div class="box-header with-border">  
                <h3 class="box-title">Selamat Datang di Dashboard</h3>  
            </div>  
            <div class="box-body">  
                <div class="row">  
                    <div class="col-md-4">  
                        <a href="<?= site_url('v_input_nilai') ?>" class="btn btn-primary btn-block">Input Nilai</a>  
                    </div>  
                    <!-- Tambahkan kolom lain sesuai kebutuhan -->  
                </div>  
            </div>  
        </div>  
    </section>  
</div>  
